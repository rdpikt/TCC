      function cadastroMV()
      {
      
      window.location = '../Layout/cadastro.html'

      }
      function loginMV(){
            window.location = '../Layout/login.html'
      }
      //cadastro animações

      